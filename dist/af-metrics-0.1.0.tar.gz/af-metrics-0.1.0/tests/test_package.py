from __future__ import annotations

import af_metrics as m


def test_version():
    assert m.__version__
